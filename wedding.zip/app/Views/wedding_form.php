<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($wedding) ? 'Edit' : 'Create' ?> Wedding Invitation</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #8b5cf6;
            --secondary: #ec4899;
            --bg: #f8fafc;
            --card: #ffffff;
            --text: #1e293b;
            --border: #e2e8f0;
        }
        body {
            font-family: 'Outfit', sans-serif;
            background-color: var(--bg);
            color: var(--text);
            margin: 0;
            padding: 30px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1);
        }
        h1 {
            font-size: 1.75rem;
            margin-bottom: 30px;
            background: linear-gradient(to right, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .section-title {
            font-size: 1.1rem;
            font-weight: 600;
            margin-top: 40px;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--bg);
            color: var(--primary);
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-size: 0.9rem;
            font-weight: 600;
            color: #475569;
        }
        input[type="text"], input[type="date"], textarea, select {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border);
            border-radius: 10px;
            box-sizing: border-box;
            font-family: inherit;
        }
        .grid-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        .btn-group {
            margin-top: 40px;
            display: flex;
            gap: 15px;
        }
        .btn {
            padding: 12px 30px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            cursor: pointer;
            border: none;
        }
        .btn-save { background: var(--primary); color: white; }
        .btn-cancel { background: #f1f5f9; color: #475569; }
        .error { color: #ef4444; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h1><?= isset($wedding) ? 'Edit Invitation' : 'Create New Invitation' ?></h1>

        <?php if (isset($error)): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="section-title">Site Configuration</div>
            <div class="grid-2">
                <div class="form-group">
                    <label>Internal Title (e.g. Billy & Jane Wedding)</label>
                    <input type="text" name="title" value="<?= htmlspecialchars($wedding['title'] ?? '', ENT_QUOTES) ?>" required>
                </div>
                <div class="form-group">
                    <label>URL Slug (e.g. billyandjane)</label>
                    <input type="text" name="slug" id="slug-input" value="<?= htmlspecialchars($wedding['slug'] ?? '', ENT_QUOTES) ?>" required
                           pattern="[a-z0-9\-]+" title="Hanya huruf kecil, angka, dan tanda minus">
                    <div id="slug-status" style="font-size: 0.75rem; min-height: 1em; margin-top: 4px; font-weight: 600;"></div>
                    <div style="font-size: 0.8rem; color: #64748b; margin-top: 8px;">
                        URL Preview: <span style="color: var(--primary); font-weight: 600;"><?= $_SERVER['HTTP_HOST'] . (rtrim(str_replace('index.php', '', $_SERVER['SCRIPT_NAME']), '/') . '/') ?></span><span id="slug-preview-text" style="color: var(--primary); font-weight: 600;"><?= htmlspecialchars($wedding['slug'] ?? '', ENT_QUOTES) ?></span>
                    </div>
                </div>
            </div>

            <div class="grid-2">
                <div class="form-group">
                    <label>Start Date</label>
                    <input type="date" name="start_date" value="<?= htmlspecialchars($wedding['start_date'] ?? '', ENT_QUOTES) ?>">
                </div>
                <div class="form-group">
                    <label>End Date</label>
                    <input type="date" name="end_date" value="<?= htmlspecialchars($wedding['end_date'] ?? '', ENT_QUOTES) ?>">
                </div>
            </div>

            <div class="grid-2">
                <div class="form-group">
                    <label>Theme</label>
                    <select name="theme_path">
                        <?php 
                        $themes = array_filter(glob('themes/*'), 'is_dir');
                        foreach ($themes as $t) {
                            $t_name = basename($t);
                            $selected = ($wedding['theme_path'] ?? 'default') === $t_name ? 'selected' : '';
                            echo "<option value='$t_name' $selected>$t_name</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group" style="padding-top: 30px;">
                    <label>
                        <input type="checkbox" name="is_enabled" <?= ($wedding['is_enabled'] ?? 1) ? 'checked' : '' ?>>
                        Enabled / Active
                    </label>
                </div>
            </div>

            <div class="section-title">👰 PENGANTIN WANITA (Bride)</div>
            <div class="form-group">
                <label>Nama Lengkap</label>
                <input type="text" name="bride_name" value="<?= htmlspecialchars($wedding['bride_name'] ?? '', ENT_QUOTES) ?>">
            </div>
            <div class="grid-2">
                <div class="form-group">
                    <label>Nama Panggilan</label>
                    <input type="text" name="bride_nickname" value="<?= htmlspecialchars($wedding['bride_nickname'] ?? '', ENT_QUOTES) ?>">
                </div>
                <div class="form-group">
                    <label>Putri ke berapa</label>
                    <input type="text" name="bride_order" value="<?= htmlspecialchars($wedding['bride_order'] ?? '', ENT_QUOTES) ?>">
                </div>
            </div>
            <div class="grid-2">
                <div class="form-group">
                    <label>Nama Ayah</label>
                    <input type="text" name="bride_father" value="<?= htmlspecialchars($wedding['bride_father'] ?? '', ENT_QUOTES) ?>">
                </div>
                <div class="form-group">
                    <label>Nama Ibu</label>
                    <input type="text" name="bride_mother" value="<?= htmlspecialchars($wedding['bride_mother'] ?? '', ENT_QUOTES) ?>">
                </div>
            </div>

            <div class="section-title">🤵 PENGANTIN PRIA (Groom)</div>
            <div class="form-group">
                <label>Nama Lengkap</label>
                <input type="text" name="groom_name" value="<?= htmlspecialchars($wedding['groom_name'] ?? '', ENT_QUOTES) ?>">
            </div>
            <div class="grid-2">
                <div class="form-group">
                    <label>Nama Panggilan</label>
                    <input type="text" name="groom_nickname" value="<?= htmlspecialchars($wedding['groom_nickname'] ?? '', ENT_QUOTES) ?>">
                </div>
                <div class="form-group">
                    <label>Putra ke berapa</label>
                    <input type="text" name="groom_order" value="<?= htmlspecialchars($wedding['groom_order'] ?? '', ENT_QUOTES) ?>">
                </div>
            </div>
            <div class="grid-2">
                <div class="form-group">
                    <label>Nama Ayah</label>
                    <input type="text" name="groom_father" value="<?= htmlspecialchars($wedding['groom_father'] ?? '', ENT_QUOTES) ?>">
                </div>
                <div class="form-group">
                    <label>Nama Ibu</label>
                    <input type="text" name="groom_mother" value="<?= htmlspecialchars($wedding['groom_mother'] ?? '', ENT_QUOTES) ?>">
                </div>
            </div>

            <div class="section-title">💕 AKAD NIKAH 🤝</div>
            <div class="grid-2">
                <div class="form-group">
                    <label>Hari/tanggal</label>
                    <input type="text" name="akad_date" value="<?= htmlspecialchars($wedding['akad_date'] ?? '', ENT_QUOTES) ?>">
                </div>
                <div class="form-group">
                    <label>Waktu (WIB/WITA/WIT)</label>
                    <input type="text" name="akad_time" value="<?= htmlspecialchars($wedding['akad_time'] ?? '', ENT_QUOTES) ?>">
                </div>
            </div>
            <div class="form-group">
                <label>Tempat</label>
                <textarea name="akad_place"><?= htmlspecialchars($wedding['akad_place'] ?? '', ENT_QUOTES) ?></textarea>
            </div>

            <div class="section-title">💕 RESEPSI PERNIKAHAN</div>
            <div class="grid-2">
                <div class="form-group">
                    <label>Hari/tanggal</label>
                    <input type="text" name="reception_date" value="<?= htmlspecialchars($wedding['reception_date'] ?? '', ENT_QUOTES) ?>">
                </div>
                <div class="form-group">
                    <label>Waktu (WIB/WITA/WIT)</label>
                    <input type="text" name="reception_time" value="<?= htmlspecialchars($wedding['reception_time'] ?? '', ENT_QUOTES) ?>">
                </div>
            </div>
            <div class="form-group">
                <label>Tempat</label>
                <textarea name="reception_place"><?= htmlspecialchars($wedding['reception_place'] ?? '', ENT_QUOTES) ?></textarea>
            </div>
            <div class="form-group">
                <label>Sharelok Acara (Maps Link)</label>
                <input type="text" name="reception_map_link" value="<?= htmlspecialchars($wedding['reception_map_link'] ?? '', ENT_QUOTES) ?>">
            </div>

            <div class="section-title">🎁 KIRIM HADIAH (Gift Info)</div>

            <p style="font-size:0.85rem; color:#64748b; margin-top:-10px;">Rekening 1</p>
            <div class="grid-2">
                <div class="form-group">
                    <label>Nama Pemilik Rekening</label>
                    <input type="text" name="bank1_owner" placeholder="Contoh: SYIFA AULIA FADHILLAH" value="<?= $wedding['bank1_owner'] ?? '' ?>">
                </div>
                <div class="form-group">
                    <label>Nama Bank</label>
                    <input type="text" name="bank1_name" placeholder="Contoh: Bank Mandiri" value="<?= $wedding['bank1_name'] ?? '' ?>">
                </div>
            </div>
            <div class="form-group">
                <label>Nomor Rekening</label>
                <input type="text" name="bank1_acc" placeholder="Contoh: 1480020167113" value="<?= $wedding['bank1_acc'] ?? '' ?>">
            </div>

            <p style="font-size:0.85rem; color:#64748b; margin-top:5px;">Rekening 2</p>
            <div class="grid-2">
                <div class="form-group">
                    <label>Nama Pemilik Rekening</label>
                    <input type="text" name="bank2_owner" placeholder="Contoh: ABDUL ROCHIM MUIZ" value="<?= $wedding['bank2_owner'] ?? '' ?>">
                </div>
                <div class="form-group">
                    <label>Nama Bank</label>
                    <input type="text" name="bank2_name" placeholder="Contoh: Bank Mandiri" value="<?= $wedding['bank2_name'] ?? '' ?>">
                </div>
            </div>
            <div class="form-group">
                <label>Nomor Rekening</label>
                <input type="text" name="bank2_acc" placeholder="Contoh: 1480021027993" value="<?= $wedding['bank2_acc'] ?? '' ?>">
            </div>

            <div class="section-title">🖼️ GALERI FOTO</div>
            <div class="form-group">
                <label>Image URLs (one per line) <small style="font-weight:400;color:#94a3b8;">— atau kelola foto via tombol "🖼️ Galeri" di dashboard</small></label>
                <textarea name="gallery_urls" rows="5" placeholder="https://example.com/photo1.jpg"><?php 
                    if (isset($id)) {
                        $gallery = Models\Wedding::getGalleryUrls($id);
                        // Only show external URLs (uploaded ones managed separately)
                        $extUrls = array_filter($gallery, fn($u) => str_starts_with($u, 'http'));
                        echo implode("\n", $extUrls);
                    }
                ?></textarea>
            </div>

            <?php if (isset($id)): ?>
            <div class="section-title">📝 BUKU TAMU & RSVP</div>
            <div style="background: #f8fafc; padding: 15px; border-radius: 10px; max-height: 400px; overflow-y: auto; border: 1px solid var(--border);">
                <?php 
                $messages = Models\Wedding::getMessages($id);
                if (empty($messages)): ?>
                    <p style="text-align: center; color: #64748b; font-size: 0.9rem;">Belum ada pesan dari tamu.</p>
                <?php else: ?>
                    <?php foreach ($messages as $m): 
                        $avatar  = Models\Wedding::gravatarUrl($m['email'] ?? '', 40);
                        $isHadir = (bool)$m['attendance'];
                    ?>
                        <div style="display:flex; gap:12px; align-items:flex-start; margin-bottom:12px; padding-bottom:12px; border-bottom:1px solid #e2e8f0;">
                            <img src="<?= $avatar ?>" width="40" height="40" style="border-radius:50%; flex-shrink:0;">
                            <div style="flex:1;">
                                <div style="display:flex; justify-content:space-between; align-items:center; gap:5px; flex-wrap:wrap;">
                                    <div>
                                        <strong style="font-size:0.9rem;"><?= $m['name'] ?></strong>
                                        <span style="font-size:0.7rem; color:#94a3b8; margin-left:6px;"><?= $m['email'] ?></span>
                                    </div>
                                    <div style="display:flex; gap:6px; align-items:center;">
                                        <span class="status-badge <?= $isHadir ? 'status-on' : 'status-off' ?>" style="font-size:0.65rem;">
                                            <?= $isHadir ? 'Hadir' : 'Tidak Hadir' ?>
                                        </span>
                                        <a href="../../admin/guestbook/delete/<?= $m['id'] ?>"
                                           onclick="return confirm('Hapus komentar ini?')"
                                           style="font-size:0.7rem; background:#fee2e2; color:#dc2626; padding:3px 8px; border-radius:6px; text-decoration:none; font-weight:600;">
                                            Hapus
                                        </a>
                                    </div>
                                </div>
                                <p style="margin:4px 0 0; font-size:0.82rem; color:#475569;"><?= $m['message'] ?></p>
                                <?php if (!empty($m['reply'])): ?>
                                <div style="margin-top:8px; background:#fef9f2; padding:8px 10px; border-radius:6px; border-left:2px solid var(--primary);">
                                    <strong style="font-size:0.75rem; color:var(--primary); display:block;">Balasan Anda:</strong>
                                    <p style="margin:2px 0 0; font-size:0.8rem; color:#64748b;"><?= nl2br(htmlspecialchars($m['reply'])) ?></p>
                                </div>
                                <?php endif; ?>
                                <small style="color:#cbd5e1; font-size:0.7rem; display:block; margin-top:6px;"><?= $m['created_at'] ?> — IP: <?= $m['ip_address'] ?></small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <div class="btn-group">
                <button type="submit" class="btn btn-save">Save Invitation</button>
                <a href="<?= isset($wedding) ? '../../admin' : '../admin' ?>" class="btn btn-cancel">Cancel</a>
            </div>
        </form>
    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const slugInput = document.getElementById('slug-input');
        const slugStatus = document.getElementById('slug-status');
        const previewText = document.getElementById('slug-preview-text');
        const weddingId = <?= (int)($id ?? 0) ?>;
        // In this file, we can't easily get $base unless we re-calculate it or hope it's global
        const baseUrl = '<?= rtrim(str_replace('index.php', '', $_SERVER['SCRIPT_NAME']), '/') . '/' ?>';
        
        let debounceTimer;

        slugInput.addEventListener('input', function() {
            const rawVal = this.value.toLowerCase()
                .replace(/\s+/g, '-')
                .replace(/[^a-z0-9\-]/g, '');
            
            // Update Preview
            previewText.textContent = rawVal;

            // Clear status if empty
            if (rawVal.length === 0) {
                slugStatus.textContent = '';
                return;
            }

            // Debounce API call
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                fetch(`${baseUrl}api/check-slug?slug=${rawVal}&exclude=${weddingId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.available) {
                            slugStatus.textContent = '✅ ' + data.message;
                            slugStatus.style.color = '#10b981';
                        } else {
                            slugStatus.textContent = '❌ ' + data.message;
                            slugStatus.style.color = '#ef4444';
                        }
                    })
                    .catch(err => console.error('Error:', err));
            }, 500);
        });
    });
    </script>
</body>
</html>
